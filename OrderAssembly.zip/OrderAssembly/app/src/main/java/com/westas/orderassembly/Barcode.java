package com.westas.orderassembly;

import java.util.Date;

public class Barcode {
    public String Barcode;
    public double Quantity;
    public Date DateEnd;
}
