package com.westas.orderassembly.invoice_items;

public enum TypeInvoice {transfer, purchase,invoice_1c}
