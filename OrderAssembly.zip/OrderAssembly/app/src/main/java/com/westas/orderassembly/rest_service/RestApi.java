package com.westas.orderassembly.rest_service;

import com.westas.orderassembly.accept_invoice.ListAcceptedInvoice;
import com.westas.orderassembly.invoice_items.InvoiceItem;
import com.westas.orderassembly.invoice_items.ListInvoiceItem;
import com.westas.orderassembly.invoice.ListTransferInvoice;
import com.westas.orderassembly.subdivision.ListSubdivision;

import retrofit2.Call;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface RestApi {

    @POST("/Service/json/GetListSubdivision")
    public Call<TResponce<ListSubdivision>> GetListSubdivision();

    @POST("/Service/json/GetListTransferInvoice")
    public Call<TResponce<ListTransferInvoice>>GetListTransferInvoice(@Query("uid_customer") String uid_customer);

    @POST("/Service/json/GetListPurchaseInvoice")
    public Call<TResponce<ListAcceptedInvoice>>GetListAcceptInvoice(@Query("date") String date);

    @POST("/Service/json/UpdatePurchaseInvoices")
    public Call<TResponce>UpdatePurchaseInvoices(@Query("date") String date);

    @POST("/Service/json/SetQuantityItem")
    public Call<TResponce>SetQuantityItem(@Query("uid_invoice") String uid_invoice, @Query("uid_item") String uid_item, @Query("quantity") float quantity, @Query("barcode_item") String barcode_item);

    @POST("/Service/json/AddItemToInvoice")
    public Call<TResponce>AddItemToInvoice(@Query("uid_invoice") String uid_invoice, @Query("barcode_item") String barcode_item);

    @POST("/Service/json/DeleteItemFromInvoice")
    public Call<TResponce>DeleteItemFromInvoice(@Query("uid_invoice") String uid_invoice, @Query("uid_item") String uid_item, @Query("barcode_item") String barcode_item);

    @POST("/Service/json/CheckItem")
    public Call<TResponce<InvoiceItem>>CheckItem(@Query("barcode_item") String barcode_item);

    @POST("/Service/json/GetItemsOfInvoice")
    public Call<TResponce<ListInvoiceItem>>GetItemsOfInvoice(@Query("uid_invoice") String uid_invoice);

    @POST("/Service/json/PrintInvoice")
    public Call<TResponce>PrintInvoice(@Query("uid_invoice") String uid_invoice, @Query("num_term") int num_term);

    @POST("/Service/json/PrintLabel")
    public Call<TResponce>PrintLabel(@Query("uid_invoice") String uid_invoice, @Query("uid_item") String uid_item, @Query("count_label") int count_label, @Query("num_term") int num_term);

    @POST("/Service/json/CloseInvoice")
    public Call<TResponce>CloseInvoice(@Query("uid_invoice") String uid_invoice);

    @POST("/Service/json/ClosePurchaseInvoice")
    public Call<TResponce>ClosePurchaseInvoice(@Query("uid_invoice") String uid_invoice);

    @POST("/Service/json/GetResultSynchronizedInvoice")
    public Call<TResponce>GetResultSynchronizedInvoice(@Query("uid_invoice") String uid_invoice);

    @POST("/Service/json/GetInvoices1C")
    public Call<TResponce<ListTransferInvoice>>GetInvoices1C();

    @POST("/Service/json/CloseInvoice1C")
    public Call<TResponce>CloseInvoice1C(@Query("uid_invoice") String uid_invoice);

    @POST("/Service/json/GetItemsOfInvoice1C")
    public Call<TResponce<ListInvoiceItem>>GetItemsOfInvoice1C(@Query("uid_invoice") String uid_invoice);

    @POST("/Service/json/SetQuantityItem1C")
    public Call<TResponce>SetQuantityItem1C(@Query("uid_invoice") String uid_invoice, @Query("uid_item") String uid_item, @Query("quantity") float quantity, @Query("barcode_item") String barcode_item);

}
