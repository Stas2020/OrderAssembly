package com.westas.orderassembly.dialog;

public interface TCallBackDialogQuantity {
    void OnChangeQuantity(float quantity, TTypeForm type);
}
