package com.westas.orderassembly.invoice;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.westas.orderassembly.MainActivity;
import com.westas.orderassembly.R;
import com.westas.orderassembly.invoice_items.ItemsInvoiceActivity;
import com.westas.orderassembly.invoice_items.TypeInvoice;
import com.westas.orderassembly.rest_service.TOnResponce;
import com.westas.orderassembly.rest_service.TResponce;

import java.util.Date;

public class ListTransferInvoice1C_Activity extends AppCompatActivity implements View.OnClickListener{
    private Toolbar toolbar;
    private TextView num_invoice;
    private RecyclerView ListInvoiceRecyclerView;
    private LinearLayoutManager linearLayoutManager;
    private ListTransferInvoiceAdapter listInvoiceAdapter;
    private ListTransferInvoice list_invoice;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_transfer_invoice1c_activity);

        InitToolbar();
    }

    @Override
    public void onResume() {
        super.onResume();

        GetListInvoice();
    }

    private void InitToolbar()
    {
        num_invoice = findViewById(R.id.num_invoice);
        num_invoice.setText("Накладные");
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                onBackPressed();// возврат на предыдущий activity
            }
        });
    }

    private void InitRecyclerView()
    {
        ListInvoiceRecyclerView = findViewById(R.id.list_invoice1C);
        linearLayoutManager = new LinearLayoutManager(this);
        ListInvoiceRecyclerView.setLayoutManager(linearLayoutManager);

        listInvoiceAdapter = new ListTransferInvoiceAdapter(this, list_invoice, this);
        ListInvoiceRecyclerView.setAdapter(listInvoiceAdapter);
    }

    @Override
    public void onClick(View view) {
        int itemPosition = ListInvoiceRecyclerView.getChildLayoutPosition(view);

        Date date_invoice = list_invoice.GetInvoice(itemPosition).date;
        String uid_invoice = list_invoice.GetInvoice(itemPosition).uid;
        String num_doc = list_invoice.GetInvoice(itemPosition).num_doc;

        list_invoice.SelectInvoice(itemPosition);

        Intent intent = new Intent(this, ItemsInvoiceActivity.class);
        intent.putExtra("uid_invoice",uid_invoice);
        intent.putExtra("num_doc",num_doc);
        intent.putExtra("date_invoice",date_invoice);
        intent.putExtra("type_invoice", TypeInvoice.invoice_1c);


        startActivity(intent);
    }

    private void GetListInvoice()
    {

        MainActivity.GetRestClient().GetListInvoice1C(new TOnResponce<ListTransferInvoice>() {
            @Override
            public void OnSuccess(TResponce<ListTransferInvoice> responce) {

                if(!responce.Success)
                {
                    Toast.makeText(getApplicationContext(), responce.Message, Toast.LENGTH_SHORT).show();
                    return;
                }


                String uid ="";
                if(list_invoice!= null){
                    uid = list_invoice.GetUidSelected();
                }

                list_invoice = responce.Data_;

                if(!uid.isEmpty()){
                    list_invoice.SelectedByUid(uid);
                }

                InitRecyclerView();
            }

            @Override
            public void OnFailure(Throwable t) {
                Toast.makeText(getApplicationContext(), "Ошибка при получении списка накладных!  " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

}