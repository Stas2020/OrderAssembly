package com.westas.orderassembly;

import java.util.Date;

public class TransferInvoice {
    public String Number;
    public Date DateInvoice;
    public int toSubdivision;
}
