package com.westas.orderassembly.setting;

public class Settings {
    public String host;
    public int port;
    public int num_term;
}
