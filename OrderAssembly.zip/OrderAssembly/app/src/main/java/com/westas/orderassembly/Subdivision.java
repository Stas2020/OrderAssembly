package com.westas.orderassembly;

import com.google.gson.annotations.SerializedName;

public class Subdivision {

    @SerializedName("number")
    public int number;
    @SerializedName("name")
    public String name;
}
