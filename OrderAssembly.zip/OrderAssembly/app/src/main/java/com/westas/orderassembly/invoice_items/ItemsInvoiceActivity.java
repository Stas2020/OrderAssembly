package com.westas.orderassembly.invoice_items;


import android.content.Intent;
import android.content.SharedPreferences;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;


import com.westas.orderassembly.MainActivity;
import com.westas.orderassembly.R;
import com.westas.orderassembly.calculator.ParseBarcode;
import com.westas.orderassembly.calculator.QRCode;
import com.westas.orderassembly.dialog.TCallBackDialog;
import com.westas.orderassembly.dialog.TCallBackDialogQuantity;
import com.westas.orderassembly.dialog.TDialogForm;
import com.westas.orderassembly.barcode_reader.TOnReadBarcode;
import com.westas.orderassembly.dialog.TDialogQuestion;
import com.westas.orderassembly.dialog.TTypeForm;
import com.westas.orderassembly.rest_service.TOnResponce;
import com.westas.orderassembly.rest_service.TResponce;

import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class ItemsInvoiceActivity extends AppCompatActivity implements  View.OnClickListener, View.OnLongClickListener, TOnReadBarcode, TCallBackDialogQuantity
{

    private RecyclerView ListGoodsRecyclerView;
    private ItemsInvoiceAdapter listGoodsAdapter;
    private ListInvoiceItem list_invoiceItem;
    private LinearLayoutManager linearLayoutManager;
    private Toolbar toolbar;
    private TextView invoice_date;
    private TextView invoice_number;
    private TextView subdivision_name;
    private TDialogForm dialog_quantity;
    private TDialogForm dialog_print_label;
    private TDialogQuestion dialog_question;
    private int selected_position;


    private String uid_subdivision ;
    private String name_subdivision ;
    private String uid_invoice ;
    private String num_doc ;

    private ParseBarcode parseBarcode;
    private TypeInvoice type_invoice;


    int num_term;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_items_invoice);

        InitToolbar();
        MainActivity.GetBarcodeReader().SetListren(this);

        dialog_quantity = new TDialogForm(ItemsInvoiceActivity.this,ItemsInvoiceActivity.this,"Количество", TTypeForm.change);
        dialog_print_label = new TDialogForm(ItemsInvoiceActivity.this,ItemsInvoiceActivity.this,"Печать этикетки",TTypeForm.label);
        dialog_question = new TDialogQuestion(this,"Удалить?");

        Bundle parametr = getIntent().getExtras();
        if(parametr!=null){
            uid_subdivision = parametr.getString("uid_subdivision");
            name_subdivision = parametr.getString("name_subdivision");
            uid_invoice = parametr.getString("uid_invoice");
            num_doc = parametr.getString("num_doc");
            type_invoice = (TypeInvoice)parametr.get("type_invoice");

            Date date = Calendar.getInstance().getTime();
            DateFormat dateFormat = new SimpleDateFormat("dd MMM");

            SetInvoiceInfo(dateFormat.format(date), "№ "+num_doc, name_subdivision);
        }

        parseBarcode = new ParseBarcode();

        FloatingActionButton floating_button_down = (FloatingActionButton) findViewById(R.id.floating_button_down);
        floating_button_down.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PageDown();
            }
        });

        num_term = MainActivity.GetSettings().num_term;

    }

    @Override
    public void onResume() {
        super.onResume();

        GetItemsInvoice();
    }

    private void PageDown()
    {
        int count_item = listGoodsAdapter.getItemCount();
        ListGoodsRecyclerView.smoothScrollToPosition(count_item);
        Toast.makeText(getApplicationContext(), "Page down!  ", Toast.LENGTH_SHORT).show();
    }
    private void PageUp()
    {
        ListGoodsRecyclerView.smoothScrollToPosition(0);
        Toast.makeText(getApplicationContext(), "Page up!  ", Toast.LENGTH_SHORT).show();
    }
    private void GetItemsInvoice()
    {
        switch (type_invoice)
        {
            case purchase:
            {
                GetTransferInvoiceGestori();
                break;
            }
            case transfer:
            {
                GetTransferInvoiceGestori();
                break;
            }
            case invoice_1c:
            {
                GetTransferInvoiceGestori_1C();
                break;
            }
        }

    }
    private  void GetTransferInvoiceGestori_1C()
    {
        MainActivity.GetRestClient().GetItemsOfInvoice1C(uid_invoice, new TOnResponce<ListInvoiceItem>() {
            @Override
            public void OnSuccess(TResponce<ListInvoiceItem> responce) {

                if(!responce.Success)
                {
                    Toast.makeText(getApplicationContext(), responce.Message, Toast.LENGTH_SHORT).show();
                    return;
                }

                list_invoiceItem = responce.Data_;
                list_invoiceItem.SortingItem();

                InitRecyclerView();
            }

            @Override
            public void OnFailure(Throwable t) {
                Toast.makeText(getApplicationContext(), "Ошибка при получении списка товаров в накладной!  " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private  void GetTransferInvoiceGestori()
    {
        MainActivity.GetRestClient().GetItemsOfInvoice(uid_invoice, new TOnResponce<ListInvoiceItem>() {
            @Override
            public void OnSuccess(TResponce<ListInvoiceItem> responce) {

                if(!responce.Success)
                {
                    Toast.makeText(getApplicationContext(), responce.Message, Toast.LENGTH_SHORT).show();
                    return;
                }

                list_invoiceItem = responce.Data_;
                list_invoiceItem.SortingItem();

                InitRecyclerView();
            }

            @Override
            public void OnFailure(Throwable t) {
                Toast.makeText(getApplicationContext(), "Ошибка при получении списка товаров в накладной!  " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        switch (type_invoice)
        {
            case transfer: {
                getMenuInflater().inflate(R.menu.menu_items_of_invoice, menu);
                break;
            }
            case purchase:{
                getMenuInflater().inflate(R.menu.menu_items_purchase, menu);
                break;
            }
            case invoice_1c:
            {
                getMenuInflater().inflate(R.menu.menu_items_of_invoice_1c, menu);
                break;
            }
            default:{
                return true;
            }

        }

        //Код с рефлексией, используемый для включения в пункты меню иконок
        if(menu.getClass().getSimpleName()
                .equals("MenuBuilder")){
            try{
                Method m = menu.getClass()
                        .getDeclaredMethod (
                                "setOptionalIconsVisible",
                                Boolean.TYPE);
                m.setAccessible(true);
                m.invoke(menu, true);
            }
            catch(NoSuchMethodException e){
                System.err.println("onCreateOptionsMenu");
            }
            catch(Exception e){
                throw new RuntimeException(e);
            }
        }

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.print:
                PrintInvoice();
                return true;
            case R.id.close:
                CloseInvoice();
                return true;
            case R.id.add_item:
                AddItemToInvoice();
                return true;
            case R.id.info_by_invoice:
                InfoByInvoice();
                return true;
            case R.id.close_purchase:
                ClosePurchaseInvoice();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void InitToolbar()
    {
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                onBackPressed();// возврат на предыдущий activity
            }
        });

        invoice_date = findViewById(R.id.invoice_date);
        invoice_number = findViewById(R.id.invoice_number);
        subdivision_name = findViewById(R.id.subdivision_name);
    }

    private void SetInvoiceInfo(String date, String number_invoice, String name_subdivision)
    {
        invoice_date.setText(date);
        invoice_number.setText(number_invoice);
        subdivision_name.setText(name_subdivision);
    }

    private void InitRecyclerView()
    {
        ListGoodsRecyclerView = findViewById(R.id.list_items_invoice);
        linearLayoutManager = new LinearLayoutManager(this);
        ListGoodsRecyclerView.setLayoutManager(linearLayoutManager);


        ListGoodsRecyclerView.setItemAnimator(new DefaultItemAnimator());
        listGoodsAdapter = new ItemsInvoiceAdapter(this, list_invoiceItem, this,this);
        ListGoodsRecyclerView.setAdapter(listGoodsAdapter);


        SwipeCallback swipe_callback = new SwipeCallback()
        {
            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
                final int position = viewHolder.getAdapterPosition();
                InvoiceItem item = listGoodsAdapter.GetItem(position);
                listGoodsAdapter.removeItem(position);
                EventDeleteItemFromInvoice(item, position);
            }
        };
        ItemTouchHelper itemTouchhelper = new ItemTouchHelper(swipe_callback);
        itemTouchhelper.attachToRecyclerView(ListGoodsRecyclerView);
    }

    private void CloseInvoice()
    {
        switch (type_invoice)
        {
            case transfer: {
                CloseInvoiceGestori();
                break;
            }
            case purchase:{
                CloseInvoiceGestori();
                break;
            }
            case invoice_1c:
            {
                CloseInvoice1C();
                break;
            }
        }
    }

    private void CloseInvoiceGestori()
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Закрытие накладной");
        builder.setMessage("Идет передача данных в GESTORI");
        AlertDialog dialog = builder.create();
        dialog.setCancelable(false);
        dialog.show();

        MainActivity.GetRestClient().CloseInvoice(uid_invoice, new TOnResponce() {
            @Override
            public void OnSuccess(TResponce responce) {
                Toast.makeText(getApplicationContext(),  responce.Message, Toast.LENGTH_SHORT).show();
                GetItemsInvoice();
                dialog.hide();
            }

            @Override
            public void OnFailure(Throwable t) {
                Toast.makeText(getApplicationContext(), "Ошибка!  " + t.getMessage(), Toast.LENGTH_SHORT).show();

                dialog.setMessage("Ошибка!  " + t.getMessage());
                dialog.setCancelable(true);
            }

        });
    }
    private void CloseInvoice1C()
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Закрытие накладной");
        builder.setMessage("Идет передача данных в 1C");
        AlertDialog dialog = builder.create();
        dialog.setCancelable(false);
        dialog.show();

        MainActivity.GetRestClient().CloseInvoice1C(uid_invoice, new TOnResponce() {
            @Override
            public void OnSuccess(TResponce responce) {
                Toast.makeText(getApplicationContext(),  responce.Message, Toast.LENGTH_SHORT).show();
                GetItemsInvoice();
                dialog.hide();
            }

            @Override
            public void OnFailure(Throwable t) {
                Toast.makeText(getApplicationContext(), "Ошибка!  " + t.getMessage(), Toast.LENGTH_SHORT).show();

                dialog.setMessage("Ошибка!  " + t.getMessage());
                dialog.setCancelable(true);
            }

        });
    }
    private void ClosePurchaseInvoice()
    {
        MainActivity.GetRestClient().ClosePurchaseInvoice(uid_invoice, new TOnResponce() {
            @Override
            public void OnSuccess(TResponce responce) {
                Toast.makeText(getApplicationContext(),  responce.Message, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void OnFailure(Throwable t) {
                Toast.makeText(getApplicationContext(), "Ошибка!  " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }

        });
    }
    private void PrintInvoice()
    {
        switch (type_invoice)
        {
            case transfer: {
                PrintInvoiceGestori();
                break;
            }
            case purchase:{
                PrintInvoiceGestori();
                break;
            }
            case invoice_1c:
            {
                PrintInvoiceGestori1C();
                break;
            }
        }
    }
    private void PrintInvoiceGestori()
    {
        if(!list_invoiceItem.CheckAllItemSynchronized())
        {
            Toast.makeText(getApplicationContext(), "Ошибка! Не все данные отправлены в GESTORI.  ", Toast.LENGTH_SHORT).show();
            AlertSound();
            return;
        }

        MainActivity.GetRestClient().PrintInvoice(uid_invoice, num_term, new TOnResponce() {
            @Override
            public void OnSuccess(TResponce responce) {
                Toast.makeText(getApplicationContext(),  responce.Message, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void OnFailure(Throwable t) {
                Toast.makeText(getApplicationContext(), "Ошибка!  " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
    private void PrintInvoiceGestori1C()
    {

    }
    private void EventDeleteItemFromInvoice(InvoiceItem item, int position)
    {
        dialog_question.Show(item.GetBarcode() + " " + item.GetName(), new TCallBackDialog() {
            @Override
            public void OnSuccess(boolean flag) {
                if (flag)
                {
                    MainActivity.GetRestClient().DeleteItemFromInvoice(uid_invoice, item.GetUid(), item.GetBarcode(), new TOnResponce() {
                        @Override
                        public void OnSuccess(TResponce responce) {
                            Toast.makeText(getApplicationContext(),  responce.Message, Toast.LENGTH_SHORT).show();
                        }
                        @Override
                        public void OnFailure(Throwable t) {
                            Toast.makeText(getApplicationContext(), "Ошибка!  " + t.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
                }
                else
                {
                    listGoodsAdapter.restoreItem(item, position);
                }
            }
        });
    }

    private void AddItemToInvoice()
    {
        Intent intent = new Intent(this, AddItemToInvoiceActivity.class);
        intent.putExtra("uid_invoice",uid_invoice);
        startActivity(intent);
    }

    private void InfoByInvoice() {
        Intent intent = new Intent(this, InfoInvoiceActivity.class);
        intent.putExtra("uid_invoice",uid_invoice);
        startActivity(intent);
    }
    //Клик по Item в RecyclerView or click on button close_invoice
    @Override
    public void onClick(View view)
    {
        selected_position = ListGoodsRecyclerView.getChildLayoutPosition(view);

        InvoiceItem item = list_invoiceItem.GetItems(selected_position);

        SelectItem(item);
        NotifyDataSetChangedReciclerView();

        String name = item.GetName();
        double quant = item.GetQuantity();
        dialog_quantity.Show(name,quant);
    }

    @Override
    public boolean onLongClick(View v) {
        dialog_print_label.Show("Количество этикеток",0);
        return false;
    }

    @Override
    public void OnChangeQuantity(float quantity, TTypeForm type_)
    {
        switch (type_)
        {
            case label: {
                PrintLabel((int)quantity,list_invoiceItem.GetItems(selected_position));
                break;
            }
            case change:{
                InvoiceItem item = list_invoiceItem.GetItems(selected_position);
                item.SetQuantity(quantity);
                switch (type_invoice)
                {
                    case invoice_1c:
                    {
                        ChangeQuantityOnServer1С(item);
                    }
                    default:
                    {
                        ChangeQuantityOnServer(item);
                    }
                }
                MovePositionToLastPlace(item);
                NotifyDataSetChangedReciclerView();
                ScrolToLastPosition();

                break;
            }
        }
    }

    private void PrintLabel(int count_label, InvoiceItem invoiceItem)
    {
        MainActivity.GetRestClient().PrintLabel(uid_invoice, invoiceItem.GetUid(), count_label, num_term, new TOnResponce() {
            @Override
            public void OnSuccess(TResponce responce) {
                Toast.makeText(getApplicationContext(),  responce.Message, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void OnFailure(Throwable t) {
                Toast.makeText(getApplicationContext(), "Ошибка!  " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void Alert(String message)
    {
        Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
        AlertSound();
    }

    private void AlertSound()
    {
        Uri notify = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        Ringtone r = RingtoneManager.getRingtone(getApplicationContext(), notify);
        r.play();
    }

    private void ShowMessage(String message)
    {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Alert(message);
            }
        });
    }

    @Override
    public void OnReadCode(final String code)
    {
        switch (type_invoice)
        {
            case invoice_1c:
            {
                InvoiceItem item = list_invoiceItem.GetItemsByBarcode(code);
                if(item == null)
                {
                    ShowMessage("Не нашел товар!");
                    return;
                }
                float quantity = item.GetQuantity() + item.GetBox(code).quantity_in_box;
                item.SetQuantity(quantity);
                ChangeQuantityOnServer1С(item);
                SelectItem(item);
                MovePositionToLastPlace(item);
                NotifyDataSetChangedReciclerView();
                ScrolToLastPosition();

                break;
            }
            default:
            {
                QRCode qr_code = parseBarcode.ParseJSON(code);
                if (qr_code == null)
                {
                    ShowMessage("Не удалось прочитать QRCode!");
                    return;
                }
                InvoiceItem item = list_invoiceItem.GetItemsByBarcode(qr_code.code);
                if(item == null)
                {
                    ShowMessage("Не нашел товар!");
                    return;
                }
                item.SetQuantity(item.GetRequiredQuantity());
                ChangeQuantityOnServer(item);
                SelectItem(item);
                MovePositionToLastPlace(item);

                NotifyDataSetChangedReciclerView();
                ScrolToLastPosition();

                break;
            }
        }

    }

    private void ScrolToLastPosition()
    {
        int pos = list_invoiceItem.GetLastPosition();
        linearLayoutManager.scrollToPositionWithOffset(pos, 200);
    }
    private void MovePositionToLastPlace(InvoiceItem item)
    {
        list_invoiceItem.MovePositionToLastPlace(item);
    }
    private void SelectItem(InvoiceItem item)
    {
        list_invoiceItem.SelectItem(item);
    }

    private void NotifyDataSetChangedReciclerView()
    {
        runOnUiThread(() -> {
            listGoodsAdapter.notifyDataSetChanged();
        });
    }

    private void ChangeQuantityOnServer(InvoiceItem item) {

        MainActivity.GetRestClient().SetQuantityItem(uid_invoice, item.GetUid(), item.GetQuantity(), item.GetBarcode(), new TOnResponce() {
            @Override
            public void OnSuccess(TResponce responce) {
                Toast.makeText(getApplicationContext(),  responce.Message, Toast.LENGTH_SHORT).show();
            }
            @Override
            public void OnFailure(Throwable t) {
                Toast.makeText(getApplicationContext(), "Ошибка!  " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }

        });
    }

    private void ChangeQuantityOnServer1С(InvoiceItem item) {

        MainActivity.GetRestClient().SetQuantityItem1C(uid_invoice, item.GetUid(), item.GetQuantity(), item.GetBarcode(), new TOnResponce() {
            @Override
            public void OnSuccess(TResponce responce) {
                Toast.makeText(getApplicationContext(),  responce.Message, Toast.LENGTH_SHORT).show();
            }
            @Override
            public void OnFailure(Throwable t) {
                Toast.makeText(getApplicationContext(), "Ошибка!  " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    /*
    private void SynchronizeItems()
    {
        List<InvoiceItem> items = list_invoiceItem.GetItemsNotSynchronized();
        for(InvoiceItem item:items)
        {
            ChangeQuantityOnServer(item.uid, item.barcode, item.quantity);
        }
    }

     */

}
