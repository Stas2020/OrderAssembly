package com.westas.orderassembly.barcode_reader;

public interface TOnReadBarcode {
     void OnReadCode(String code);
}
