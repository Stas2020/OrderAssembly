package com.westas.orderassembly.dialog;

public interface TCallBackDialog {
    void OnSuccess(boolean flag);
}
