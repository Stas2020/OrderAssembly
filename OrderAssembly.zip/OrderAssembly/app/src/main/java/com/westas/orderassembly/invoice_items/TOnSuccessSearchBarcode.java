package com.westas.orderassembly.invoice_items;

public interface TOnSuccessSearchBarcode {
    public void OnSuccessSearchBarcode(InvoiceItem item);
}
