package com.westas.orderassembly.dialog;

public enum TTypeForm {change, label}
