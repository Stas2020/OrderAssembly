package com.westas.orderassembly;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class ListInvoiceItem {
    public ListInvoiceItem()
    {
        list = new ArrayList<>();

        InvoiceItem invoiceItem = new InvoiceItem();
        invoiceItem.barcode = "4523345";
        invoiceItem.name = "Пирог Черри Банана 180г";
        invoiceItem.required_quantity = 23;
        invoiceItem.unit = "кг.";

        list.add(invoiceItem);
        invoiceItem = new InvoiceItem();
        invoiceItem.barcode = "452312";
        invoiceItem.name = "Кофе КАПУЧИНО 150мл";
        invoiceItem.required_quantity = 78;
        invoiceItem.unit = "кг.";

        list.add(invoiceItem);
        invoiceItem = new InvoiceItem();
        invoiceItem.barcode = "822174";
        invoiceItem.name = "Цыплёнок на даче 210г";
        invoiceItem.required_quantity = 0.4;
        invoiceItem.unit = "кг.";

        list.add(invoiceItem);
        invoiceItem = new InvoiceItem();
        invoiceItem.barcode = "2343698";
        invoiceItem.name = "Салат Капуста кимчи 200г";
        invoiceItem.required_quantity = 765;
        invoiceItem.unit = "кг.";

        list.add(invoiceItem);
        invoiceItem = new InvoiceItem();
        invoiceItem.barcode = "460712598320";
        invoiceItem.name = "Маслины вяленые п/ф";
        invoiceItem.required_quantity = 6;
        invoiceItem.unit = "кг.";

        list.add(invoiceItem);
        invoiceItem = new InvoiceItem();
        invoiceItem.barcode = "76543698";
        invoiceItem.name = "Тар-тар из говядины 210г";
        invoiceItem.required_quantity = 234;
        invoiceItem.unit = "кг.";

        list.add(invoiceItem);
        invoiceItem = new InvoiceItem();
        invoiceItem.barcode = "45239876";
        invoiceItem.name = "Сэт мини бургеров 800г";
        invoiceItem.required_quantity = 0.4;
        invoiceItem.unit = "кг.";

        list.add(invoiceItem);
        invoiceItem = new InvoiceItem();
        invoiceItem.barcode = "1243698";
        invoiceItem.name = "Гранд бургер 550г";
        invoiceItem.required_quantity = 67.4;
        invoiceItem.unit = "кг.";

        list.add(invoiceItem);
        invoiceItem = new InvoiceItem();
        invoiceItem.barcode = "4523698";
        invoiceItem.name = "Котлета д/бургера 90г";
        invoiceItem.required_quantity = 40.4;
        invoiceItem.unit = "кг.";

        list.add(invoiceItem);
        invoiceItem = new InvoiceItem();
        invoiceItem.barcode = "4523698";
        invoiceItem.name = "Пожарская котлета 240г";
        invoiceItem.required_quantity = 55.4;
        invoiceItem.unit = "кг.";

        list.add(invoiceItem);
        invoiceItem = new InvoiceItem();
        invoiceItem.barcode = "5523698";
        invoiceItem.name = "Бургер Крабс 250г";
        invoiceItem.required_quantity = 0.4;
        invoiceItem.unit = "кг.";

        list.add(invoiceItem);
        invoiceItem = new InvoiceItem();
        invoiceItem.barcode = "4523698";
        invoiceItem.name = "Молоко сгущенное 80г";
        invoiceItem.required_quantity = 0.4;
        invoiceItem.unit = "кг.";

        list.add(invoiceItem);
        invoiceItem = new InvoiceItem();
        invoiceItem.barcode = "7623698";
        invoiceItem.name = "Наггетсы сырные 170г";
        invoiceItem.required_quantity = 0.4;
        invoiceItem.unit = "кг.";

        list.add(invoiceItem);
        invoiceItem = new InvoiceItem();
        invoiceItem.barcode = "452312";
        invoiceItem.name = "Кофе КАПУЧИНО 150мл";
        invoiceItem.required_quantity = 78;
        invoiceItem.unit = "кг.";

        list.add(invoiceItem);
        invoiceItem = new InvoiceItem();
        invoiceItem.barcode = "822174";
        invoiceItem.name = "Цыплёнок на даче 210г";
        invoiceItem.required_quantity = 0.4;
        invoiceItem.unit = "кг.";

        list.add(invoiceItem);
        invoiceItem = new InvoiceItem();
        invoiceItem.barcode = "2343698";
        invoiceItem.name = "Салат Капуста кимчи 200г";
        invoiceItem.required_quantity = 765;
        invoiceItem.unit = "кг.";

        list.add(invoiceItem);
        invoiceItem = new InvoiceItem();
        invoiceItem.barcode = "8763698";
        invoiceItem.name = "Маслины вяленые п/ф";
        invoiceItem.required_quantity = 0.4;
        invoiceItem.unit = "кг.";

        list.add(invoiceItem);
        invoiceItem = new InvoiceItem();
        invoiceItem.barcode = "76543698";
        invoiceItem.name = "Тар-тар из говядины 210г";
        invoiceItem.required_quantity = 234;
        invoiceItem.unit = "кг.";

        list.add(invoiceItem);
        invoiceItem = new InvoiceItem();
        invoiceItem.barcode = "45239876";
        invoiceItem.name = "Сэт мини бургеров 800г";
        invoiceItem.required_quantity = 0.4;
        invoiceItem.unit = "кг.";

        list.add(invoiceItem);
        invoiceItem = new InvoiceItem();
        invoiceItem.barcode = "1243698";
        invoiceItem.name = "Гранд бургер 550г";
        invoiceItem.required_quantity = 67.4;
        invoiceItem.unit = "кг.";

        list.add(invoiceItem);
        invoiceItem = new InvoiceItem();
        invoiceItem.barcode = "4527773698";
        invoiceItem.name = "Котлета д/бургера 90г";
        invoiceItem.required_quantity = 40.4;
        invoiceItem.unit = "кг.";

        list.add(invoiceItem);
        invoiceItem = new InvoiceItem();
        invoiceItem.barcode = "460712598322";
        invoiceItem.name = "Пожарская котлета 240г";
        invoiceItem.required_quantity = 5.4;
        invoiceItem.unit = "кг.";

        list.add(invoiceItem);
        invoiceItem = new InvoiceItem();
        invoiceItem.barcode = "460712598";
        invoiceItem.name = "Бургер Крабс 250г";
        invoiceItem.required_quantity = 0.4;
        invoiceItem.unit = "кг.";

        list.add(invoiceItem);
        invoiceItem = new InvoiceItem();
        invoiceItem.barcode = "4523698";
        invoiceItem.name = "Молоко сгущенное 80г";
        invoiceItem.required_quantity = 0.4;
        invoiceItem.unit = "кг.";

        list.add(invoiceItem);
        invoiceItem = new InvoiceItem();
        invoiceItem.barcode = "7623698";
        invoiceItem.name = "Наггетсы сырные 170г";
        invoiceItem.required_quantity = 0.4;
        invoiceItem.unit = "кг.";

        list.add(invoiceItem);
    }

    @SerializedName("list_invoice_item")
    private List<InvoiceItem> list;

    public InvoiceItem GetItems(int position)
    {
        return list.get(position);
    }

    public int GetSize()
    {
        return list.size();
    }

    public boolean VerifyGoods(double quantity, String code)
    {
        int position = 0;
        for (InvoiceItem itm: list)
        {
            if (itm.barcode.equals(code))
            {
                itm.quantity += quantity;

                if (itm.quantity > itm.required_quantity)
                {
                    itm.verify = Satus.over;
                }
                if (itm.quantity == itm.required_quantity)
                {
                    itm.verify = Satus.equally;
                }
                if (itm.quantity < itm.required_quantity)
                {
                    itm.verify = Satus.less;
                }


                //Меняем позицию найденного item на первую
                if(position != 0)
                {
                    list.remove(position);
                    list.add(0,itm);
                }

                return true;
            }
            position++;
        }

        return false;
    }

    public void ChangeQuantity(double quantity, String code)
    {
        int position = 0;
        for (InvoiceItem itm: list)
        {
            if (itm.barcode.equals(code))
            {
                itm.quantity = quantity;

                if (itm.quantity > itm.required_quantity)
                {
                    itm.verify = Satus.over;
                }
                if (itm.quantity == itm.required_quantity)
                {
                    itm.verify = Satus.equally;
                }
                if (itm.quantity < itm.required_quantity)
                {
                    itm.verify = Satus.less;
                }


                //Меняем позицию найденного item на первую
                if(position != 0)
                {
                    list.remove(position);
                    list.add(0,itm);
                }

                break;

            }
            position++;
        }
    }

}
