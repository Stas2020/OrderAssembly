package com.westas.orderassembly;

import android.support.v7.widget.CardView;

import com.google.gson.annotations.SerializedName;

enum Satus {less, equally, over};

public class InvoiceItem {

    @SerializedName("barcode")
    public String barcode;
    @SerializedName("name")
    public String name;
    @SerializedName("quantity")
    public double quantity;
    @SerializedName("required_quantity")
    public double required_quantity;
    @SerializedName("unit")
    public String unit;
    @SerializedName("verify")
    public Satus verify;
}
