package com.westas.orderassembly;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

import static java.lang.Math.random;

public class ListSubdivision {
    public ListSubdivision()
    {
        this.list = new ArrayList<>();


        Subdivision subdivision = new Subdivision();
        subdivision.name = "Кофейня на Рождественке";
        subdivision.number = 101;
        this.list.add(subdivision);

        subdivision = new Subdivision();
        subdivision.name = "Кофейня на Никитской";
        subdivision.number = 104;
        this.list.add(subdivision);

        subdivision = new Subdivision();
        subdivision.name = "Четыре Ветра";
        subdivision.number = 111;
        this.list.add(subdivision);

        subdivision = new Subdivision();
        subdivision.name = "Кофейня на Кудринской";
        subdivision.number = 130;
        this.list.add(subdivision);

        subdivision = new Subdivision();
        subdivision.name = "Неглинная";
        subdivision.number = 177;
        this.list.add(subdivision);

        subdivision = new Subdivision();
        subdivision.name = "Осенняя";
        subdivision.number = 180;
        this.list.add(subdivision);

        subdivision = new Subdivision();
        subdivision.name = "Депо Бар";
        subdivision.number =  191;
        this.list.add(subdivision);

        subdivision = new Subdivision();
        subdivision.name = "Аврора";
        subdivision.number = 205;
        this.list.add(subdivision);

        subdivision = new Subdivision();
        subdivision.name = "Шереметьево-1";
        subdivision.number = 212;
        this.list.add(subdivision);

        subdivision = new Subdivision();
        subdivision.name = "Бургерная";
        subdivision.number = 255;
        this.list.add(subdivision);

        subdivision = new Subdivision();
        subdivision.name = "Мэрия";
        subdivision.number = 264;
        this.list.add(subdivision);
    }

    @SerializedName("list_subdivision")
    public java.util.List<Subdivision> list;
}
