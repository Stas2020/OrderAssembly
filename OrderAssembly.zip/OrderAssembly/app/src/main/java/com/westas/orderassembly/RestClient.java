package com.westas.orderassembly;

import android.content.SharedPreferences;
import android.widget.Toast;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RestClient {

    private Retrofit retrofit;
    private RestApi rest_api;
    private SharedPreferences shared_preferance;

    //Создаем Retrofit
    public void BuildRetrofit()
    {
        OkHttpClient okHttpClient = new OkHttpClient().newBuilder()
                .connectTimeout(60, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .writeTimeout(60, TimeUnit.SECONDS)
                .build();

        //Читаем настройки
        String NameServer = shared_preferance.getString("NAME_SERVER","localhost");

        assert NameServer != null;
        NameServer = NameServer.replaceAll("\n|\r\n", "");
        NameServer = NameServer.trim();

        String Port = shared_preferance.getString("NAME_PORT","8000");
        Port = Port.trim();
        String url = "http://"+NameServer+":"+Port;
        //NameServer = "192.168.222.111";
        retrofit = new Retrofit.Builder()
                .baseUrl(url) //Базовая часть адреса
                .client(okHttpClient)
                .addConverterFactory(GsonConverterFactory.create()) //Конвертер, необходимый для преобразования JSON'а в объекты
                .build();

        rest_api= retrofit.create(RestApi.class); //Создаем объект, при помощи которого будем выполнять запросы
    }

    //Отправка данных на REST сервера
    public void SendDataToRestServer()
    {

        Call<ListSubdivision> list_subdivision = rest_api.GetDataSubdivision();

        list_subdivision.enqueue(new Callback<ListSubdivision>() {
            @Override
            public void onResponse(Call<ListSubdivision> call, Response<ListSubdivision> response) {
                OnResponceSend(response.body());
            }

            @Override
            public void onFailure(Call<ListSubdivision> call, Throwable t) {

                OnFailureResponceSend(t);
            }
        });
    }

    //Событие удачного ответа от REST сервера
    public void OnResponceSend(ListSubdivision list_subdivision)
    {
        if (list_subdivision.list.isEmpty())
        {

        }
        else
        {

        }

    }
    //Событие НЕ удачного ответа от REST сервера
    public void OnFailureResponceSend(Throwable txt)
    {
        if (txt instanceof IOException) {


        }
    }

    //Получение данных с REST сервера
    public void GetDataFromRestService()
    {
        try
        {
            String InvoiceUID = "ertyu4545454dfderer";
            Call<ListInvoiceItem> invoice_item = rest_api.GetInvoiceItem(InvoiceUID);

            invoice_item.enqueue(new Callback<ListInvoiceItem>() {
                @Override
                public void onResponse(Call<ListInvoiceItem> call, Response<ListInvoiceItem> response) {

                    OnResponceGet(response.body());
                }
                @Override
                public void onFailure(Call<ListInvoiceItem> call, Throwable t) {

                    OnFailureResponceGet(t);
                }
            });
        }
        catch(Exception e)
        {
            String err_nes =  e.getMessage();

        }

    }
    //Событие удачного ответа от REST сервера
    public  void OnResponceGet(ListInvoiceItem invoice_item)
    {
        if (invoice_item != null)
        {

        }
        else
        {

        }

    }
    //Событие НЕ удачного ответа от REST сервера
    public void OnFailureResponceGet(Throwable txt)
    {
        if (txt instanceof IOException) {


        }

    }





}
